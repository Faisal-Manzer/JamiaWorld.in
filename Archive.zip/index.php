<?php
include 'data/faisal/connect.php';
include 'data/faisal/saru.php';
header("HTTP/1.1 200 OK");
include 'app/appshell.php';
?>
